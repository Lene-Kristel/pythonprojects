# Jogo do Zumbi = Zombie Dice
# 13 dados
# G = Green     6 dados
# Y = Yellow    4 dados
# R = Red       3 dados
TODOS_OS_DADOS = "GGGGGGYYYYRRR"

# Dado fácil 3 cérebros, 2 passos, 1 Tiro
DADO_VERDE = "CCCPPT"

# Dado médio 2 cérebros, 2 passos, 2 Tiros
DADO_AMARELO = "CCPPTT"

# Dado difícil 1 cérebro, 2 passos, 3 Tiros
DADO_VERMELHO = "CPPTTT"

from random import randrange


# Seleciona uma posicão aleatória na "massa de dados" que são os possíveis valores
# Essa função é genérica podendo ser usada para retornar uma posição aleatória tanto
# do tubo de dados quanto de um próprio dado
def escolheUm(massa_de_dados):
    return massa_de_dados[randrange(0, len(massa_de_dados) - 1)]


# Retorna o vsalor de uma face do dado de acordo com a sua cor
def rolar_dado(cor_dado):
    if cor_dado.upper() == "G":
        result = escolheUm(DADO_VERDE)
    elif cor_dado.upper() == "Y":
        result = escolheUm(DADO_AMARELO)
    else:
        result = escolheUm(DADO_VERMELHO)

    return result


# função usada para trocar de jpogador
def passa_a_vez():
    # As declarações "global" aqui, é necessário pois a função altera os valores das variávies
    # globais. Sem essa declaração o python não consegue modificar o valor das variáveis
    global vez  # Controla qual jogador está na vez "jogando"
    global tiros  # Controla a quantidade de Tiros que um jogador levou. Quando passa a vez, a quantidade é zerada
    global tubo_de_dados  # É o tubo onde ficam os dados
    global repete_dados  # São os dados que rolaram e ficaram com o valor Passos, esses devem ser jogados novamente

    vez = vez + 1  # Próximo da vez
    tiros = 0  # Zera a quantodade de tiros que o jogador levou
    tubo_de_dados = TODOS_OS_DADOS  # Reinicia o tubo de dados
    repete_dados = []   # Se passa a vez, então não tem mais dados a se repetir

    # Se todos já jogaram, então volta para o primeiro
    if vez >= quantidade_de_jogadores:
        mostrar_placar()  # Se todos já jogaram, apresenta um "PACAR"
        vez = 0  # Reinicia a vez para o primeiro jogador
        continuar_jogando = input("Continuar jogando [S/N]? ").upper() == "S"  # Pergunta se quer continuar ou PARAR de jogar
        if continuar_jogando != True:
            print("\n\n\nSaiu do JOGO!")
            exit(0)


# Função para exibir o placar
def mostrar_placar():
    # Pula 3 linhas
    print("\n\n\n")
    print("PLACAR")
    # Exibe o título "PLACAR"
    print("Nome \t\t\t Cérebros")
    print("------------------------------------------------")
    # Imprime os nomes dos jogadores e o placar de cada um
    for cont in range(0, quantidade_de_jogadores):
        # Se jogador perdeu, monta uma string para ser exibida na tela
        if perdeu[cont]:
            exibir = str(jogadores[cont]) + "\t\t" + str(placar[cont]) + " PERDEU "
        else:
            exibir = str(jogadores[cont]) + "\t\t" + str(placar[cont])

        # Se o jogador perdeu, mostra que ele perdeu
        print(exibir)
    print("------------------------------------------------")
    print("\n\n")


# Se um jogador ganhar o jogo (Obter 13 cérebros primeiro), finaliza o jogo.
def jogador_ganhou(quem):
    mostrar_placar()
    print("O jogador: " + jogadores[quem] + " GANHOU!!!")
    print("FIM DE JOGO!!!")
    exit(0)

# Função que só retorna a cor de acordo com o valor passado
def pega_cor(cor):
    if cor == "G":
        return "Verde"
    elif cor == "Y":
        return "Amarelo"
    else:
        return "Vermelho"


# Função que só retorna a jogada de acordo com o valor passado
def pega_jogada(jogada):
    if jogada == "C":
        return "Cérebro"
    elif jogada == "T":
        return "Tiro"
    else:
        return "Passos"


# Verifica se um jogador perdeu o jogo.
def perdeu_jogo():
    print("\n\nPerdeu!!!\n\n")
    perdeu[vez] = True
    ganhou_jogo = 0
    continua_jogando = 0
    indice = -1

    for i in perdeu:
        indice = indice + 1
        if not i:
            continua_jogando = continua_jogando + 1
            ganhou_jogo = indice

    if continua_jogando == 1:
        jogador_ganhou(ganhou_jogo)
        exit()

    # Se perdeu não joga mais. Passa a vez
    passa_a_vez()

# Pula 10 linhas
for i in range(10):
    print("\n")

# Escreve o nome do Jogo
print("Zombie Dice")

# Cria as variáveis do jogo
tubo_de_dados = TODOS_OS_DADOS
quantidade_de_jogadores = 0
jogadores = []
placar = []
perdeu = []
jogada = ""
vez = 0
tiros = 0
repete_dados = []

# Se a quantidade de jogadores não for de acordo com a quantidade permitida no jogo
# aqui foi colocado de 2 a 6 jogadores. Fica perguntando a quantidade de jogadores
# até que a quantidade seja dentro desses parâmetros.
while quantidade_de_jogadores not in range(2, 7):
    quantidade_de_jogadores = int(input("Quantos jogadores irão jogar? [2-6] "))

# De acordo com a quantidade de jogadores, faz a leitura dos nomes dos jogadores
for um in range(quantidade_de_jogadores):
    # Adiciona o jogador no quadro de jogadores
    jogadores.append(input("Digite o nome do jogador " + str(um + 1) + ": "))
    # Junto a isso adiciona um placar para ele = 0 pq ainda não começou o jogo
    placar.append(0)
    # Marca False no registro de quem perdeu pq ele ainda nem jogou, então não perdeu ainda
    perdeu.append(False)

# Loop principal do jogo
while True:
    escolhidos = []
    opcao_jogador = ""

    # Se o jogador perdeu, quando for a vez dele, pula.
    if perdeu[vez]:
        # Escreve que o jogador perdeu
        print("O jogador: " + jogadores[vez] + ", PERDEU!!!")
        # Passa a vez
        passa_a_vez()
        # Reinicia o Loop
        continue

    # Pergunta e só aceita as opções J = jogar ou P = passar a vez
    # Igual o que foi feito na quantidade de jogadores
    while opcao_jogador not in ["J", "P"]:
        print("\nEstá na vez do jogador: " + jogadores[vez] + ", jogar.")
        opcao_jogador = input("Quer [J]ogar ou [P]assar a vez? ").upper()

    # Se for Jogar
    if opcao_jogador == "J":
        # Verifica se tem algum dado para repetir (passos)
        if len(repete_dados) > 0:
            escolhidos = repete_dados  # pega os dados que tem que repetir
            repete_dados = []  # Depois que já pegou os dados, zera para não repetir outra vez

        # Pega os dados que faltam para completar 3 dados
        for i in range(0, 3 - len(escolhidos)):
            # Escolhe um dado (aleatório) do tubo
            escolhido = escolheUm(tubo_de_dados)
            # Remove o dado escolhido do tubo

            tubo_de_dados = tubo_de_dados.replace(escolhido, "", 1)
            # Coloca os dados kuntos
            escolhidos.append(escolhido)

        # De acordo com os dados tirados do tubo, rola os dados
        for dado in escolhidos:
            # Pega o valor do dado rolado
            jogada = rolar_dado(dado)

            # Testa os valores dos dados
            if jogada == "C":  # Se for cérebro, soma um ponto no placar
                placar[vez] = placar[vez] + 1
                # Volta o dado para o tubo
                tubo_de_dados = tubo_de_dados + jogada

                # Testa se já conseguiu 13 cérebros, se conseguiu encerra o jogo e escreve quem venceu
                if placar[vez] >= 13:
                    jogador_ganhou(vez)

            # Se um dado for tiro, soma 1 na quantidade que o jogador pode receber.
            elif jogada == "T":
                tiros = tiros + 1

                # Volta o dado para o tubo
                tubo_de_dados = tubo_de_dados + jogada

            # Se não foi cérebro nem tiro, então é passos. Separa os dados para serem roaldos novamente
            else:
                repete_dados.append(dado)

            # Exibe qual foi o valor que o dado apresentou
            print("\tDado de cor " + pega_cor(dado) + " mostrou [" + pega_jogada(jogada) + "]")

        # Se o jogador tomou 3 tiros, perde o jogo
        if tiros >= 3:
            print("Tomou 3 tiros")
            perdeu_jogo()

    # Se a opção escolhida foi Passar a vez, passa a vez
    else:
        passa_a_vez()

# FIM